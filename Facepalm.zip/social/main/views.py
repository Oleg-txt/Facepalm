from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Profile, Palm
from .forms import PalmForm, SignUpForm, ProfilePicForm, UpdateUserForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django import forms
from django.contrib.auth.models import User

def home(request):
    if request.user.is_authenticated:
        form = PalmForm(request.POST or None, request.FILES or None)
        if request.method == "POST":
            if form.is_valid():
                palm = form.save(commit=False)
                palm.user = request.user
                palm.save()
                messages.success(request, ("Your Palm Has Been Posted"))
                return redirect('home')
            
        palms = Palm.objects.all().order_by("-created_at")
        return render(request, 'home.html', {"palms":palms, "form":form})
    else:
        palms = Palm.objects.all().order_by("-created_at")
        return render(request, 'home.html', {"palms":palms})


def profile_list(request):
    if request.user.is_authenticated:
        profiles = Profile.objects.exclude(user=request.user)
        return render(request, 'profile_list.html', {"profiles":profiles})
    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def unfollow(request, pk):
    if request.user.is_authenticated:
        # Get the profile to unfollow
        profile = Profile.objects.get(user_id=pk)
        # Unfollow the user
        request.user.profile.follows.remove(profile)
        # Save our profile
        request.user.profile.save()

        # Return message
        messages.success(request, (f"You Have Successfully Unfollowed {profile.user.username}"))
        return redirect(request.META.get("HTTP_REFERER"))


    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def follow(request, pk):
    if request.user.is_authenticated:
        # Get the profile to unfollow
        profile = Profile.objects.get(user_id=pk)
        # Unfollow the user
        request.user.profile.follows.add(profile)
        # Save our profile
        request.user.profile.save()

        # Return message
        messages.success(request, (f"You Have Successfully Followed {profile.user.username}"))
        return redirect(request.META.get("HTTP_REFERER"))


    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def profile(request, pk):
    if request.user.is_authenticated:
        profile = Profile.objects.get(user_id=pk)
        palms = Palm.objects.filter(user_id=pk).order_by("-created_at")
        # Post Form logic
        if request.method == "POST":
            # Get current user ID
            current_user_profile = request.user.profile
            # Get form data
            action = request.POST['follow']
            # Decide to follow or unfollow
            if action == "unfollow":
                current_user_profile.follows.remove(profile)
            elif action == "follow":
                current_user_profile.follows.add(profile)
                # Save the profile
            current_user_profile.save()

        return render(request, "profile.html", {"profile":profile, "palms":palms})
    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def followers(request, pk):
    if request.user.is_authenticated:
        if request.user.id == pk:
            profiles = Profile.objects.get(user_id=pk)
            return render(request, 'followers.html', {"profiles":profiles})
        else:
            messages.success(request, ("That's Not Your Profile Page"))
            return redirect('home')
            
    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def follows(request, pk):
    if request.user.is_authenticated:
        if request.user.id == pk:
            profiles = Profile.objects.get(user_id=pk)
            return render(request, 'follows.html', {"profiles":profiles})
        else:
            messages.success(request, ("That's Not Your Profile Page"))
            return redirect('home')
            
    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, ("You Have Been Logged In!"))
            return redirect('home')
        else:
            messages.success(request, ("There was an error logging in... Please try again"))
            return redirect('login')

    else:    
        return render(request, "login.html", {})


def logout_user(request):
    logout(request)
    messages.success(request, ("You Have Been Logged Out"))
    return redirect('home')

def register_user(request):
    form = SignUpForm()
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            # first_name = form.cleaned_data['first_name']
            # last_name = form.cleaned_data['last_name']
            # email = form.cleaned_data['email']
            # Log in user
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, ("You have successfully registered! Welcome!"))
            return redirect('home')


    return render(request, "register.html", {'form':form})


def update_user(request):
    if request.user.is_authenticated:
        current_user = User.objects.get(id=request.user.id)
        profile_user = Profile.objects.get(user__id=request.user.id)
        # Get Forms
        user_form = UpdateUserForm(request.POST or None, request.FILES or None, instance=current_user)
        profile_form = ProfilePicForm(request.POST or None, request.FILES or None, instance=profile_user)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()

            login(request, current_user)
            messages.success(request, ("Your Profile Has Been Updated!"))
            return redirect('home')

        return render(request, "update_user.html", {'user_form':user_form, 'profile_form':profile_form})
    else:    
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def change_password(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)  # Зберігає сесію, щоб не розлогінювати
                messages.success(request, ("Your Password Was Successfully Updated!"))
                return redirect('home')
            else:
                for error in list(form.errors.values()):
                    messages.error(request, error)
        else:
            form = PasswordChangeForm(request.user)
        return render(request, "change_password.html", {'form': form})
    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')

def palm_like(request, pk):
    if request.user.is_authenticated:
        palm = get_object_or_404(Palm, id=pk)
        if palm.likes.filter(id=request.user.id):
            palm.likes.remove(request.user)
        else:
            palm.likes.add(request.user)

        return redirect(request.META.get("HTTP_REFERER"))




    else:
        messages.success(request, ("You Must Be Logged In To View This Page..."))
        return redirect('home')


def palm_show(request, pk):
    palm = get_object_or_404(Palm, id=pk)
    if palm:
        return render(request, "show_palm.html", {'palm':palm})
    else:
        messages.success(request, ("That Palm Does Not Exist..."))
        return redirect('home')


def delete_palm(request, pk):
    if request.user.is_authenticated:
        palm = get_object_or_404(Palm, id=pk)
        # Check to see if you own the palm
        if request.user.username == palm.user.username:
            # Delete The Palm
            palm.delete()

            messages.success(request, ("The Palm Has Been Deleted!"))
            return redirect(request.META.get("HTTP_REFERER"))
        else:
            messages.success(request, ("You Don't Own That Palm!"))
            return redirect('home')
    else:
        messages.success(request, ("Please Log In To Continue..."))
        return redirect(request.META.get("HTTP_REFERER"))


def edit_palm(request, pk):
    if request.user.is_authenticated:
        # Grab The Palm!
        palm = get_object_or_404(Palm, id=pk)
        # Check to see if you own the palm
        if request.user.username == palm.user.username:
            form = PalmForm(request.POST or None, instance=palm)
            if request.method == "POST":
                if form.is_valid():
                    palm = form.save(commit=False)
                    palm.user = request.user
                    palm.save()
                    messages.success(request, ("Your Palm Has Been Updated!"))
                    return redirect('home')
            else:
                return render(request, "edit_palm.html", {'form':form, 'palm':palm})

        else:
            messages.success(request, ("You Don't Own That Palm!"))
            return redirect('home')
    else:
        messages.success(request, ("Please Log In To Continue..."))
        return redirect('home')


def search(request):
    if request.method == "POST":
        # Grab the form field input
        search = request.POST['search']
        # Search the database
        searched = Palm.objects.filter(body__contains=search)

        return render(request, 'search.html', {'search':search, 'searched':searched})
    else:
        return render(request, 'search.html', {})


def search_user(request):
    if request.method == "POST":
        # Grab the form field input
        search = request.POST['search']
        # Search the database
        searched = User.objects.filter(username__contains=search)

        return render(request, 'search_user.html', {'search':search, 'searched':searched})
    else:
        return render(request, 'search_user.html', {})