from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),
    path('profile_list/', views.profile_list, name='profile_list'),
    path('profile/<int:pk>', views.profile, name='profile'),
    path('profile/followers/<int:pk>', views.followers, name='followers'),
    path('profile/follows/<int:pk>', views.follows, name='follows'),
    path('login/', views.login_user, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('register/', views.register_user, name='register'),
    path('update_user/', views.update_user, name='update_user'),
    path('change_password/', views.change_password, name='change_password'),
    path('palm_like/<int:pk>', views.palm_like, name="palm_like"),
    path('palm_show/<int:pk>', views.palm_show, name="palm_show"),
    path('unfollow/<int:pk>', views.unfollow, name="unfollow"),
    path('follow/<int:pk>', views.follow, name="follow"),
    path('delete_palm/<int:pk>', views.delete_palm, name="delete_palm"),
    path('edit_palm/<int:pk>', views.edit_palm, name="edit_palm"),
    path('search/', views.search, name='search'),
    path('search_user/', views.search_user, name='search_user'),
]
